package com.shadow.controllers;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.qianlong.BorrowInfoBo;
import com.shadow.BorrowEntity;
import com.shadow.RepayEntity;
import com.shadow.biz.IBorrowBiz;
import com.shadow.biz.IRepayBiz;
import com.shadow.biz.IUserBiz;
import com.shadow.biz.constants.SystemConstant;
import com.shadow.biz.constants.TimeConstant;
import com.shadow.biz.util.Amount2String;
import com.shadow.dao.IRepayDao;

/**
 * @author 管黎明
 *
 *         All rights reserved.
 */
@Controller
public class RepayController {
	@Autowired
	private IBorrowBiz borrowBiz;
	@Autowired
	private IRepayBiz repayBiz;
	@Autowired
	private IRepayDao repayDao;
	@Autowired
	private IUserBiz userBiz;

	@RequestMapping("/repay")
	public ModelAndView repay(final HttpSession session, @RequestParam("repayAccount") final BigDecimal repayAccount)
			throws Exception {
		final BorrowEntity borrowEntity = obtainCurrentUserBorrowInfo(session);
		final byte currentPeriod = currentPeriod(borrowEntity.getBorrowTime(), borrowEntity.getPeriod());
		acomplishForegone(borrowEntity, currentPeriod);
		final RepayEntity currentRepayEntity = repayDao.queryByBorrowIdAndPeriod(borrowEntity.getId(), currentPeriod);
		rawRepay(currentRepayEntity, borrowEntity, repayAccount);
		return new ModelAndView("repaySuccess");
	}
	
	@RequestMapping("/test")
	@ResponseBody
	public String repay2()
			throws Exception {
		return "哈哈2";
	}

	@RequestMapping("/repayInfo")
	public ModelAndView repayInfo(final HttpSession session) throws Exception {
		final BorrowEntity borrowEntity = obtainCurrentUserBorrowInfo(session);
		final byte currentPeriod = currentPeriod(borrowEntity.getBorrowTime(), borrowEntity.getPeriod());
		acomplishForegone(borrowEntity, currentPeriod);
		final List<RepayEntity> repayList = repayDao.queryByBorrowId(borrowEntity.getId());
		final ModelAndView mv = new ModelAndView("repayInfoPage");
		mv.addObject("repayList", repayList);
		BorrowInfoBo borrowBo = new BorrowInfoBo();
		borrowBo.setBorrowAmount(borrowEntity.getBorrowAmount());
		borrowBo.setMonthlyRepay(Amount2String.transfer(repayBiz.calculateMonthlyRepay(borrowEntity.getBorrowAmount(),
				borrowEntity.getPeriod())));
		borrowBo.setOnAccount(borrowEntity.getOnAccount());
		if (StringUtils.equals(borrowEntity.getBorrowType(), SystemConstant.BORROW_MODE_INSTALMENT)) {
			borrowBo.setPeriod(borrowEntity.getPeriod());
			mv.addObject("instalmentBo", borrowBo);
		} else {
			mv.addObject("oneOffBo", borrowBo);
		}
		return mv;
	}

	@RequestMapping("/repayPage")
	public ModelAndView repayPage(final HttpSession session) throws Exception {
		final BorrowEntity borrowEntity = obtainCurrentUserBorrowInfo(session);
		final byte currentPeriod = currentPeriod(borrowEntity.getBorrowTime(), borrowEntity.getPeriod());
		acomplishForegone(borrowEntity, currentPeriod);
		final RepayEntity currentRepayEntity = repayDao.queryByBorrowIdAndPeriod(borrowEntity.getId(), currentPeriod);
		final ModelAndView mv = new ModelAndView("repayPage");
		mv.addObject("actualShouldRepay", currentRepayEntity.getActualShouldRepay());
		return mv;
	}

	/**
	 * 补充当前期数之前的还款信息
	 *
	 * @param borrow
	 *            借款信息
	 * @param currentPeriod
	 *            当前期数
	 */
	private void acomplishForegone(final BorrowEntity borrow, final byte currentPeriod) {
		final List<RepayEntity> repayEntityList = repayDao.queryByBorrowId(borrow.getId());
		final byte overduePeriod = repayBiz.calculateOverduePeriod(repayEntityList, currentPeriod, borrow.getId());
		outer: for (byte i = 1; i <= currentPeriod; i++) {
			for (final RepayEntity repay : repayEntityList) {
				if (repay.getPeriod() == i) {
					continue outer;
				}
			}
			repayBiz.save(borrow, repayEntityList, i, overduePeriod);
		}
	}

	private byte currentPeriod(final Date borrowTime, final byte totalPeriod) {
		final long borrowUpToNow = System.currentTimeMillis() - borrowTime.getTime() - TimeConstant.DAY_TO_TIMEMILLS;
		if (borrowUpToNow <= 0) {
			return 1;
		} else {
			return (byte) (borrowUpToNow / TimeConstant.PER_PERIOD_TO_TIMEMILLS + 1);
		}
	}

	private BorrowEntity obtainCurrentUserBorrowInfo(final HttpSession session) throws Exception {
		final long userId = userBiz.query((String) session.getAttribute(SystemConstant.SESSION_LOGIN_NAME)).getId();
		final List<BorrowEntity> borrowEntityList = borrowBiz.query(userId);
		for (final BorrowEntity borrowEntity : borrowEntityList) {
			if (StringUtils.equals(borrowEntity.getCompletelyPayOff(), "N")) {
				return borrowEntity;
			}
		}
		if(!CollectionUtils.isEmpty(borrowEntityList)){
			return borrowEntityList.get(0);
		}
		throw new Exception("无借贷信息!");
	}

	private void rawRepay(final RepayEntity currentRepayEntity, final BorrowEntity borrowEntity,
			final BigDecimal repayAccount) {
		if (StringUtils.equals(currentRepayEntity.getBalance(), "Y")) {
			currentRepayEntity.setRepay(currentRepayEntity.getRepay().add(repayAccount));
			borrowEntity.setOnAccount(borrowEntity.getOnAccount().add(repayAccount));
			borrowBiz.updateOnAccount(borrowEntity);
			repayBiz.update(currentRepayEntity);
			return;
		}
		borrowEntity.setCompletelyPayOff("N");
		if (repayAccount.compareTo(currentRepayEntity.getActualShouldRepay()) >= 0) {
			borrowEntity.setOnAccount(repayAccount.subtract(currentRepayEntity.getActualShouldRepay()));
			currentRepayEntity.setBalance("Y");
			currentRepayEntity.setActualShouldRepay(BigDecimal.ZERO);
			if (currentRepayEntity.getPeriod() >= borrowEntity.getPeriod()) {
				borrowEntity.setCompletelyPayOff("Y");
			}
		} else {
			borrowEntity.setOnAccount(borrowEntity.getOnAccount().add(repayAccount));
			currentRepayEntity.setActualShouldRepay(currentRepayEntity.getShouldRepayNoOnAccount().subtract(
					borrowEntity.getOnAccount()));
		}
		currentRepayEntity.setRepay(currentRepayEntity.getRepay().add(repayAccount));
		borrowBiz.updateOnAccount(borrowEntity);
		repayBiz.update(currentRepayEntity);

	}

}
