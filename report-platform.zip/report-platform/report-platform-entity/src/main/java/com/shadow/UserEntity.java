package com.shadow;

import lombok.Data;

/**
 * @author 管黎明
 * 
 *         All rights reserved.
 */
@Data
public class UserEntity {
	private long id;
	private String name;
	private String password;
	
}
