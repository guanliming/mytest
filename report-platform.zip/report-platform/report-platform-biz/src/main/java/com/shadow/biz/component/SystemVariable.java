package com.shadow.biz.component;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * @author guanliming
 *
 */
@Data
@EqualsAndHashCode
public class SystemVariable {
	
	private String baseDir;
	
}
