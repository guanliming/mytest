package com.qianlong;

import lombok.Data;

/**
 * @author 管黎明
 *
 *         All rights reserved.
 */
@Data
public class RegisterParamBo {
	
	private String password;
	
	private String username;

}
